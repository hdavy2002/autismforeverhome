# Module 01 — Part 2: Tailwind + Global CSS

Files:
- tailwind.config.cjs
- src/styles/global.css

Steps:
1) Upload both files to your repo root (tailwind.config.cjs) and src/styles/global.css.
2) Overwrite if prompted, commit to main.
3) Vercel will redeploy automatically.
