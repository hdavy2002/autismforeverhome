# Autism Forever Home — Branding Patch (Astro)

This patch adds your logo, colors, and marketing copy to an Astro (Astroship-like) project.

## How to apply
1) In GitHub → your repo → **Add file → Upload files**.
2) Drag **the contents of this ZIP** into the repo root.
3) When prompted, choose **Overwrite** for files that already exist.
4) Commit directly to your default branch. Vercel will redeploy automatically.

If your project uses slightly different paths, use the closest equivalents:
- `src/components/Navbar.astro` may be `src/components/Header.astro`
- `src/components/Footer.astro` may be `src/components/SiteFooter.astro`
- `src/styles/global.css` may be `src/assets/styles/global.css` or `src/styles/base.css`
- `tailwind.config.cjs` may be `tailwind.config.js` or `.ts`

## What this patch changes
- Adds `/public/logo.png` (your round badge) and uses it in Header & Footer
- Sets a warm cream background and brand link color
- Wires an autism‑friendly, muted color palette into Tailwind
- Replaces landing hero text + adds a pricing section with $0 / $5 / $20 plans

**App name:** Autism Forever Home  
**Tagline:** Leave memories that answer back.
